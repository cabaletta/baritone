Baritone Both Versions Distribution
Дата: 2026-11-08T17:23:04.347918Z
Содержимое:
  jars/ — все JAR'ы для 1.16.5 и 1.21.4 + комбинированный
  docs/ — документация
  checksums.txt — SHA1 суммы

Версии:
  1.16.5: 1.6.5 (Java 8)
  1.21.4: 1.13.1 (Java 21)

Установка:
  Скопируйте нужный JAR из jars/ в папку mods вашего Minecraft.

См. docs/MULTI_VERSION.md
